package crudmvc.model;

public class Login {
    
    private Usuario oUsuario; //representa o usuário...
    
    private boolean validaLogin(Usuario usuario) 
    {
        return false;
    }
    
    public Usuario validaUsuario(String user, String password)
    {
        return null;
    }
}